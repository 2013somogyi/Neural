import './inicio.css';

function Inicio({ aoNavegar }) {
    return (
        <div className="inicioPai">
            <div className="inicioContainer">
                <section className="landi-page-topo" id="inicio">
                    <div className="landi-hero-inner">

                        <div className="landi-page-topo-content">
                            <div className="text-page-topo">
                                <span className="text-simples-topo">
                                    <p>Gestão para assistências técnicas</p>
                                </span>
                                <h1>
                                    Sua assistência em ordem. Seu próximo passo, mais perto.
                                </h1>
                                <p className="text-descricao-topo">
                                    Organize ordens de serviço, clientes, equipe e estoque em uma
                                    plataforma feita para simplificar o dia a dia da sua empresa.
                                </p>
                            </div>

                            <div className="landi-page-actions">
                                <a href="#planos" className="btnSignup">
                                    Ver planos
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                        <path d="M5 12h14M13 6l6 6-6 6" />
                                    </svg>
                                </a>

                                <button
                                    className="btnLogin"
                                    onClick={() => aoNavegar('cadastro')}
                                >
                                    Criar minha conta
                                </button>
                            </div>

                            <p className="landi-page-hint">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" strokeLinecap="round" strokeLinejoin="round">
                                    <circle cx="12" cy="12" r="11" fill="#2f855a" />
                                    <path d="M7 12.5l3.2 3.2L17 9" stroke="#fff" strokeWidth="3" />
                                </svg>
                                Mais clareza para cuidar de cada atendimento.
                            </p>
                        </div>

                        <div className="landi-page-topo-visual">
                            <div className="landing-orbit landing-orbit-one"></div>
                            <div className="landing-orbit landing-orbit-two"></div>

                            <div className="landing-feature-cloud">
                                <div className="landing-feature-tile">
                                    <span className="tile-icon">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                            <rect x="5" y="4" width="14" height="17" rx="2" />
                                            <path d="M9 4V3h6v1M9 11h6M9 15h6" />
                                        </svg>
                                    </span>
                                    <strong>Ordens de serviço</strong>
                                </div>

                                <div className="landing-feature-tile">
                                    <span className="tile-icon">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                            <path d="M3 8l9-5 9 5v8l-9 5-9-5V8z" />
                                            <path d="M3 8l9 5 9-5M12 13v8" />
                                        </svg>
                                    </span>
                                    <strong>Estoque integrado</strong>
                                </div>

                                <div className="landing-feature-tile">
                                    <span className="tile-icon">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                            <circle cx="9" cy="8" r="3" />
                                            <circle cx="17" cy="9" r="2.5" />
                                            <path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6M15 14.5c3 0 6 1.5 6 5.5" />
                                        </svg>
                                    </span>
                                    <strong>Gestão de equipe</strong>
                                </div>

                                <div className="landing-feature-tile">
                                    <span className="tile-icon">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                            <path d="M3 3v18h18" />
                                            <path d="M7 15l4-4 3 3 5-6" />
                                        </svg>
                                    </span>
                                    <strong>Visão do negócio</strong>
                                </div>
                            </div>

                            <div className="landing-floating-note">
                                <span className="note-status-dot">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                        <path d="M5 12.5l4.5 4.5L19 7" />
                                    </svg>
                                </span>
                                <div>
                                    <strong>Informações conectadas</strong>
                                    <small>Uma rotina mais organizada</small>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>

                {/* PLANOS */}
                <section className="inicioSection" id="planos">
                    <h1 className="inicioTitulo">
                        Escolha o plano ideal para a sua empresa
                    </h1>

                    <p className="inicioSubtitulo">
                        Gerencie Ordens de Serviço, Estoque, Clientes e Finanças com
                        tecnologia Neural.
                    </p>

                    <div className="inicioPlanos">
                        {/* Plano Básico */}
                        <div className="planoCard">
                            <div>
                                <span className="planoTag">Plano Básico</span>

                                <div className="planoPreco">
                                    R$ 59,90<span>/mês</span>
                                </div>

                                <p className="planoDescricao">
                                    Ideal para pequenos técnicos e assistências de bairro.
                                </p>

                                <ul className="planoLista">
                                    <li>✔ Cadastro ilimitado de Clientes</li>
                                    <li>✔ Até 100 Ordens de Serviço por mês</li>
                                    <li>✔ Controle Básico de Estoque</li>
                                    <li>✔ Acesso seguro em nuvem</li>
                                </ul>
                            </div>

                            <button
                                className="planoBotao btnLogin"
                                onClick={() => aoNavegar('cadastro')}
                            >
                                Assinar Plano Básico
                            </button>
                        </div>

                        {/* Plano Prime */}
                        <div className="planoCard destaque">
                            <div>
                                <span className="planoTag">Mais Popular</span>

                                <div className="planoPreco">
                                    R$ 179,00<span>/mês</span>
                                </div>

                                <p className="planoDescricao">
                                    Para assistências completas com alta demanda de aparelhos.
                                </p>

                                <ul className="planoLista">
                                    <li>✔ Ordens de Serviço ilimitadas</li>
                                    <li>✔ Controle Avançado de Estoque e Peças</li>
                                    <li>✔ Gestão de Fornecedores</li>
                                    <li>✔ Relatórios de Faturamento</li>
                                    <li>✔ Suporte Prioritário 24/7</li>
                                </ul>
                            </div>

                            <button
                                className="planoBotao btnSignup"
                                onClick={() => aoNavegar('cadastro')}
                            >
                                Assinar Plano Prime
                            </button>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    );
}

export default Inicio;